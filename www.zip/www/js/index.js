// this thing use JQM js socket.io and cryptoJS
document.addEventListener('deviceready',onDeviceReady);

function onDeviceReady(){
    //making variables
    var userKey ='in this whole universe iron man is the best superhero';
    var serverLink ='';
    var defaultKey = "Part of the journy is the end. Whatever it takes";
    var encryptMsg ='';
    var socket ;
    var element;
    var recvMsg ='';
    
    var DB = window.sqlitePlugin.openDatabase({name: "vchat.db", location: 'default'});
    //make tables if not exists
    DB.transaction(function(transaction) {
        transaction.executeSql('CREATE TABLE IF NOT EXISTS messages (id integer primary key AUTOINCREMENT, sender text, msg text)');
        transaction.executeSql('CREATE TABLE IF NOT EXISTS settings (id integer primary key AUTOINCREMENT, userKey text, serverLink text)');

    });
    
    //page settings
    var maxHeight = $.mobile.getScreenHeight();
    var headerHeight = $('#oneHeader').outerHeight(true);
    $('#contents').outerHeight(maxHeight - headerHeight );
    //end of page settings 
    //disable send message button
    document.getElementById("send").disabled = true;
    //scroll to bottom
    function scrollToBottom(){
        element = document.getElementById("showMsg");
        element.scrollTop = element.scrollHeight;
    }
    
    //setting update
    DB.transaction(function(transaction){
        transaction.executeSql('SELECT * FROM settings WHERE id=1', [], function (tx, results){
            var len = results.rows.length, i;
            userKey = "in this whole universe iron man is the best superhero";
            serverLink = "http://192.168.1.10:4000";
           
            if (len !=1){
                DB.transaction(function(transaction){
                    transaction.executeSql('INSERT INTO settings (userKey, serverLink) values(?,?)',[CryptoJS.AES.encrypt(userKey, defaultKey),CryptoJS.AES.encrypt(serverLink, defaultKey)]);
                });
            }else if (len >= 1){
                for (i =0; i<1; i++){
                    userKey = (CryptoJS.AES.decrypt(results.rows.item(i).userKey, defaultKey)).toString(CryptoJS.enc.Utf8);
                    serverLink = (CryptoJS.AES.decrypt(results.rows.item(i).serverLink, defaultKey)).toString(CryptoJS.enc.Utf8);
                }
            }
            serverConnect();
            $('#serverLink').val(serverLink);
            $('#userKey').val(userKey);
        });
        
    });    
    
    //load last 100 messages
    DB.transaction(function(transaction){
        transaction.executeSql('SELECT * FROM  messages ORDER BY id DESC LIMIT 0,100',[],function (tx, results){
            var len = results.rows.length, i;
            for(i=0; i<len;i++){

                //decrypt msg
                msg = CryptoJS.AES.decrypt(results.rows.item(i).msg, defaultKey).toString(CryptoJS.enc.Utf8);
                //end of decrypt msg
                
                if (results.rows.item(i).sender =="me"){
                    $('#showMsg').prepend("<div id='msgContainerMe' ><pre id='msgBoxMe'>"+String(msg)+"</pre></div>");
                }else if (results.rows.item(i).sender == "you"){
                    $('#showMsg').prepend("<div id='msgContainer' ><pre id='msgBox'>"+String(msg)+"</pre></div>");
                }
                scrollToBottom();
            }
            
        },null);
        scrollToBottom();
    });
    
    //send messages        
    $('#send').click(function (){
       
        var msg = $('#msg').val();
        msg = msg.replace("<","&lt");
        msg = msg.replace(">","&gt");
        msg = msg.replace("/","&#47");
        msg = msg.replace("?","&#63");
        msg = msg.replace(";","&#59");
        msg = msg.replace("'","&#39");
        msg = msg.replace('"',"&#34");
        
        msg = msg.trim();
       
        if (msg.length >0){
            encryptMsg = CryptoJS.AES.encrypt(msg, defaultKey);
            encryptMsg = CryptoJS.AES.encrypt(String(encryptMsg), userKey);
            
            socket.emit('chat',{
                message:String(encryptMsg),
                id: socket.id
             });
            
             $('#showMsg').append("<div  id='msgContainerMe' ><pre id='msgBoxMe' >"+msg+"</pre></div>");
            msg = CryptoJS.AES.encrypt(msg, defaultKey);
            DB.transaction(function(transaction) {
                transaction.executeSql('INSERT INTO messages (sender , msg) values (?,?)',["me",String(msg)]);
            }); 
            $('#msg').val('');
            $('#msg').focus();
            scrollToBottom();
        }
    }); 

    //connect to settings
    function serverConnect(){
        socket = io.connect(serverLink);
        socket.on('connect',function(){
            document.getElementById("send").disabled = false;
        });
        
        socket.on("disconnect",function(){
            document.getElementById("send").disabled = true;
        });
        //save receiving chat
        socket.on('chat',function(data){
            
            recvMsg = CryptoJS.AES.decrypt(data,userKey).toString(CryptoJS.enc.Utf8);
            recvMsg = CryptoJS.AES.decrypt(recvMsg,defaultKey).toString(CryptoJS.enc.Utf8);
            
            DB.transaction(function(transaction) {
                transaction.executeSql('INSERT INTO messages (sender , msg) values (?,?)',["you",( CryptoJS.AES.encrypt(String(recvMsg), defaultKey))]);
            });
            $('#showMsg').append("<div id='msgContainer' ><pre id='msgBox'>"+recvMsg+"</pre></div>");
            scrollToBottom();
        });

    }
    //updating server link
    $('#serverLinkUpdate').click(function (){
        serverLink = $('#serverLink').val();
        DB.transaction(function(transaction) {
            transaction.executeSql("UPDATE settings SET serverLink ='"+CryptoJS.AES.encrypt(String(serverLink), defaultKey)+"' WHERE id=1",[]);
            alert("Done ! its good restart app");
            
        });
      
    });
    //updating userEncrypt key
    $('#encryptKeyUpdate').click(function (){
        userKey = $('#userKey').val();
        DB.transaction(function(transaction) {
            transaction.executeSql("UPDATE settings SET userKey ='"+CryptoJS.AES.encrypt(String(userKey), defaultKey)+"' WHERE id=1",[]);
            alert("Done ! its good restart app");
        });
      
    });
}
