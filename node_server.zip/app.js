// created by wisnshaftler
var express = require('express');
var socket = require('socket.io');
var port = process.env.PORT || 4000
var socketList =[];
//App setup

var app = express();//creating server app 

var server = app.listen(port,function(){ //you can change this socket number as you like 
    console.log("4000 listening enabled");//starting to listening port 4000 you can edit this port as you like
});
//socket setup
var io = socket(server);

//socket connection
io.on('connection',function(socket){
     //if user connected console will display it
    socketList.push(socket.id);

//chat send message
    socket.on('chat',function(data){
      for (i=0; i<socketList.length; i++){
        if (String(socket.id) != String(socketList[i])){
          io.to(String(socketList[i])).emit('chat',data.message); 
        }
      }
    });

    socket.on('disconnect', function() {
      console.log("disconnected " +socket.id);
    });
});
